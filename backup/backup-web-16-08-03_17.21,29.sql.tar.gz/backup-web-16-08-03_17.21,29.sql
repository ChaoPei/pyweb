-- MySQL dump 10.13  Distrib 5.6.30, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: web
-- ------------------------------------------------------
-- Server version	5.6.30-0ubuntu0.14.04.1
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('001466171053105de10f5df992b49c2aa108d861258f5e1000','001466129787923746d4bd44895463597d81ec6a98553d0000','Itachi','http://www.gravatar.com/avatar/8a8fcb056ae0aff3ddf3f9d31eeb43c5?d=mm&s=120','afdfa','fadfa','fafdfdsf',1466171053.10576);
INSERT INTO `blogs` VALUES ('001470215063383cb272c27db3f49de9008b86f707f03bd000','001466129787923746d4bd44895463597d81ec6a98553d0000','Itachi','http://www.gravatar.com/avatar/8a8fcb056ae0aff3ddf3f9d31eeb43c5?d=mm&s=120','STL中的查找算法','对STL中常用的查找算法进行小结','####  本文是对STL中常用的查找算法做个小结。\n\n可供查找的算法大致有：\n\n* count：计算对象区间中的数目\n* find：返回第一个对象的位置\n* binary\\_search：判断是否存在某个对象\n* lower\\_bound：返回等于或者大于指定对象的第一个位置\n* upper\\_bound：返回大于对象的第一个位置\n* equal\\_range：返回等于指定对象的元素的区间位置（构成一个pair）\n\n这些查找算法需要**序列式容器，或者数组**。**关联容器有相应的同名成员函数**(除了binary\\_search)，带有判别式的如count\\_if,find_if或者binary\\_search的派别式版本，其用法大致相同，不影响选择，所以不作考虑。\n\n<br/>\n### 1. 查找分类\n 可以按是否需要排序区间分为两组：\n \n * 需要排序：binary\\_search, lower\\_bound, upper\\_bound, equal\\_range\n * 不需要排序： find, count\n \n 很明显，排序后的查找效率更高（对数时间），但排序本身需要花费时间。而不排序的查找一般是线性时间。\n\n\n<br/>\n### 2. 无序查找\n对于count和find来说，用法有一些不同。\n\n首先，find能够返回第一个匹配对象的位置，很多时候我们都需要获得查找得到的位置，这时候find就很好用。\n另一方面， find查找到匹配对象之后就停止查找，而count则会全部遍历来统计个数，所以find效率更高。\n但是对于判别来说，find检查迭代器的位置，而count检查返回的个数。\n\n<br/>\n### 3. 有序查找\n\n* binary_search只能判断是否存在；\n* 需要知道匹配元素的位置，使用lower_bound。因为lower_bound不一定匹配，也可能是大于，所以需要检查返回位置元素是否匹配；\n	* 这地方有一个陷阱，就是查找是用到的等价比较和判别时用到的等价比较如果不一致，会出现问题。特别是对于用户定义的类，等价的比较方法。\n* equal_range本质就是同时返回了lower_bound和upper_bound的结果；\n* equal_range返回两个迭代器如果相同，则表明没有找到匹配对象\n	* 用这个方法比lower_bound更保险，不涉及对象的等价比较 \n\n引用一张别人总结的表格。\n**查找算法使用选择：**\n\n![查找算法](http://img.blog.csdn.net/20160802184401190)',1470215063.38322);

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` VALUES ('001466232688637216f143a5e7945318f73e2843cf484b7000','001466171053105de10f5df992b49c2aa108d861258f5e1000','001466129787923746d4bd44895463597d81ec6a98553d0000','Itachi','http://www.gravatar.com/avatar/8a8fcb056ae0aff3ddf3f9d31eeb43c5?d=mm&s=120','aiaiaiaiaia',1466232688.63743);

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `id_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('0014629553463740d686d7f004c40dab82c35da0a0500f2000','test@example.com','123456',0,'Test','about:blank',1462955346.37474);
INSERT INTO `users` VALUES ('001464146503207761192be248d46e0a2dd8f1b844f1e19000','test2@example.com','123456',0,'Test2','about:blank',1464146503.20768);
INSERT INTO `users` VALUES ('001466129787923746d4bd44895463597d81ec6a98553d0000','1024088134@qq.com','4bcc9bb1c858bf47ec6b32dc0bc54bf10f150421',1,'Itachi','http://www.gravatar.com/avatar/8a8fcb056ae0aff3ddf3f9d31eeb43c5?d=mm&s=120',1466129787.92339);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-03 17:21:42
