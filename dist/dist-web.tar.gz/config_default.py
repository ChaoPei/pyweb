# -*- coding:utf-8 -*-

__author__ = 'Parle'

# default configure

configs = {
    'db': {
        'host':'127.0.0.1',
        'port':3306,
        'user':'web',
        'password':'webadmin',
        'database':'web'
        },
    'session':{
        'secret':'ParleWeb'
        }
    }


