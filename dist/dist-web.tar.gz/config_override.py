# -*- coding:utf-8 -*-

__author__ = 'Parle'

# configure for override 

configs = {
    'db' : {
        'host':'219.223.197.222'
        }
    }
